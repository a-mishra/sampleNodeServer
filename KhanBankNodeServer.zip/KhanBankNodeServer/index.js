import express from 'express';
import bodyParser from 'body-parser';
import contactRoutes from './src/routes/contactRoutes';
import settingRoutes from './src/routes/settingRoutes';
import helperRoutes from './src/routes/helperRoutes';


const app = express();
const PORT = 9800;

//---------- To fix the CORS Issue -----------------------------------------------

    var cors = require('cors')
    app.use(cors())

    app.use(function(req, res, next) {
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
        next();
    });

//-------------------------------------------------------------------------------


// --------- To fix the Vulnerability Issues ------------------------------------

    var helmet = require('helmet')
    app.use(helmet())

//-------------------------------------------------------------------------------


// bodyparser setup
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

contactRoutes(app);
settingRoutes(app);
helperRoutes(app);

// serving static files
app.use(express.static('public'));

app.get('/', (req, res) =>
    res.send(`Node and express server is running on port ${PORT}`)
);

app.listen(PORT, () =>
    console.log(`your server is running on port ${PORT}`)
);

//--------------openAPI Documentation -------------------------------------------

const swaggerJsdoc = require('swagger-jsdoc');
const options = {
    swaggerDefinition: {
        // Like the one described here: https://swagger.io/specification/#infoObject
        info: {
            title: 'Khan Bank API\'s',
            version: '1.0.0',
            description: 'Khan Bank API\'s for Staic / Functional Module  ',
        },
    },
    // List of files to be processes. You can also set globs './routes/*.js'
    apis: ['./src/routes/*.js'],
};

const specs = swaggerJsdoc(options);

const swaggerUi = require('swagger-ui-express');
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(specs));

