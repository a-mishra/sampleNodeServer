
const { Client } = require('pg')
const connectionProps = {
    user: 'postgres',
    host: '127.0.0.1',
    database: 'ameyodb',
    password: '',
    port: 5432
};

export const getSettings = async (req, res) => {
    
    let sqlQuery = '';
    let values = [];
    if( (req.query.searchable != undefined && req.query.searchable != null) ) {
        sqlQuery = `'select cfmms.*, campaign_context.name as campaign_name, campaign_context.type as campaign_type from (SELECT * FROM custom_functional_message_module_settings where ${req.query.searchable}='${req.query.value}') as cfmms left join campaign_context on campaign_context.id = cfmms.campaign_id order by cfmms.date_added desc `;
    }
    else {
        sqlQuery = 'select cfmms.*, campaign_context.name as campaign_name, campaign_context.type as campaign_type from (SELECT * FROM custom_functional_message_module_settings) as cfmms left join campaign_context on campaign_context.id = cfmms.campaign_id order by cfmms.date_added desc';
    }

    const client = new Client(connectionProps)

    client.connect()
    try{
        let SQLresult = await client.query(sqlQuery,values);
        //console.log(SQLresult);

        let tagToCountMap = [];
        for(let i = 0 ; i < SQLresult.rows.length ; i++  ){
            let sqlQuery = `select ${SQLresult.rows[i].tag_code} as tag_code, count(*) from custom_functional_message_module_contacts where tag % ${SQLresult.rows[i].tag_code} = 0`;
            let SQLresultForCustomerCountForTag = await client.query(sqlQuery);
            for(let j = 0 ; j< SQLresultForCustomerCountForTag.rows.length; j++ ) {
                tagToCountMap.push(SQLresultForCustomerCountForTag.rows[j]);
                SQLresult.rows[i].records = SQLresultForCustomerCountForTag.rows[j].count;
            }
        }
        //console.log(tagToCountMap);

        res.json({ msg: 'Success', data: SQLresult.rows });
    }
    catch(e) {
        console.error(e.stack)
        res.send({ msg: 'Error ', data: 'Error while query postgres' });
    }


    // client.query(sqlQuery,values)
    //     .then(SQLresult => {
    //         res.json({ msg: 'Success', data: SQLresult.rows });
    //     })
    //     .catch(e => {
    //         console.error(e.stack)
    //         res.send({ msg: 'Error ', data: 'Error while query postgres' });
    //     })

};



export const getSettingWithId = (req, res) => {

    let sqlQuery = `select cfmms.*, campaign_context.name as campaign_name, campaign_context.type as campaign_type from (SELECT * FROM custom_functional_message_module_settings where id=${req.params.settingId}) as cfmms left join campaign_context on campaign_context.id = cfmms.campaign_id order by cfmms.date_added desc `;

    const client = new Client(connectionProps)

    client.connect()
    client.query(sqlQuery)
        .then(SQLresult => {
            res.json({ msg: 'Success', data: SQLresult.rows });
        })
        .catch(e => {
            console.error(e.stack)
            res.send({ msg: 'Error ', data: 'Error while query postgres' });
        })

};


export const getSettingWithTagCode = async (req, res) => {

    let tagArray = primeFactors(req.params.tagId)
    let returnJSON = {};
    returnJSON.msg = '';
    var data = [];

    for(let i = 0; i< tagArray.length; i++) {
        let sqlQuery = `SELECT * FROM custom_functional_message_module_settings where tag_code=${tagArray[i]}`;
        let values = [];

        const client = new Client({
            user: 'postgres',
            host: '10.10.2.22',
            database: 'ameyodb',
            password: '',
            port: 5432
        })

        client.connect();
        let SQLresult = await client.query(sqlQuery,values);
        for(let j = 0 ; j < SQLresult.rows.length ; j++)
            data.push(SQLresult.rows[j]);        
    }

    returnJSON.data = data;
    res.json(returnJSON);
}


export const addNewSetting = async (req, res) => {
    let body = req.body;

    const client = new Client(connectionProps)
    client.connect();
    let sqlQuery = '';
    let values = [];
    let SQLresult = {};
    let addedCounter = 0;
    let failedToAddCounter = 0;
    let tagCode = 1;
    // get a new tag code for insertion
    try{
        sqlQuery = `SELECT max(tag_code) as tag_code FROM custom_functional_message_module_settings`;
        SQLresult = await client.query(sqlQuery);
        tagCode = SQLresult.rows[0].tag_code;
        if( SQLresult.rows.length == 0 || tagCode == '' || tagCode == undefined || tagCode == null )
            tagCode = 1;
    } catch(e) {
        console.error(e.stack)
        res.send({ msg: 'Error ', data: e });
    }

    //find next prime number after tagCode and set TagCode = next number;

    let num = tagCode+1
    while(!(isPrime(num)))
        num++

    tagCode = num;
    //insert setting
    //--------------------------------


    try{
        sqlQuery = `insert into custom_functional_message_module_settings(campaign_id, tag, tag_code, msg_type, prompt_name, start_date, end_date, is_enabled, priority, frequency) values($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`;
        values = [body.campaign_id, body.tag, tagCode, body.msg_type, body.prompt_name, body.start_date, body.end_date, body.is_enabled, body.priority, body.frequency];
        SQLresult = await client.query(sqlQuery,values);
    } catch(e) {
        console.error(e.stack)
        res.send({ msg: 'Error ', data: e });
    }

    // now contact insertion..
    //------------------------------------
    //console.log(body);
    let contacts = body.contacts;
    let lengthOfContacts = contacts.length;
        Object.keys(contacts).forEach( async (key, index) => {
            let previoustTag = 1;
            let customerFound = false;
            // query database on cif number and find if customer exists...
            // if exists get the Tag

            try{
                sqlQuery = `SELECT tag FROM custom_functional_message_module_contacts where cif_no='${contacts[key].cif_no}'`;
                SQLresult = await client.query(sqlQuery);
                //console.log(SQLresult)
                if(SQLresult.rows.length > 0) {
                    previoustTag = SQLresult.rows[0].tag;
                    customerFound = true;
                }
            } catch(e) {
                //console.error(e.stack)
                res.send({ msg: 'Error ', data: e });
            }


            //upload the new contat with update and migrate true.
            try{
                let values = [];

                if(customerFound == true){
                    
                    let setArray = [];
                    let currentContact = contacts[key];
                    console.log(currentContact);
                    Object.keys(currentContact).forEach( (key1, index1) => {                    
                            setArray.push(`${key1} = $${index1+1}`);
                            values.push(currentContact[key1]);
                    })
                    let tag = tagCode * previoustTag;
                    sqlQuery = `update custom_functional_message_module_contacts set ${setArray.join(', ')}, tag = ${tag} where cif_no = '${contacts[key].cif_no}'`;
                    console.log(sqlQuery);
                    console.log(values);
                
                } else {
                    sqlQuery = `insert into custom_functional_message_module_contacts(phone1, phone2, phone3, cif_no, tag) values($1, $2, $3, $4, $5)`;
                    values = [contacts[key].phone1, contacts[key].phone2, contacts[key].phone3, contacts[key].cif_no, tagCode];
                    console.log(sqlQuery);

                }
                
                await client.query(sqlQuery,values);
                addedCounter++;
                if(index == lengthOfContacts-1) {
                    res.json({"Added":addedCounter, "FailedToAdd":failedToAddCounter});
                }
            } catch(e) {
               // console.log(e);
                failedToAddCounter++;
                if(index == lengthOfContacts-1) {
                    res.json({"Added":addedCounter, "FailedToAdd":failedToAddCounter});
                }
            }
        })



};


export const updateSetting = async (req, res) => {

    const client = new Client(connectionProps)
    client.connect();

    let data = req.body;
    let values = [];
    let setArray = [];
    let counter = 0;
    let currentId = req.params.settingId;

    Object.keys(data).forEach( (key, index) => {
        if(key == 'id') {
            currentId = data[key];
        } else {
            counter++;
            setArray.push(`${key} = $${counter}`);
            values.push(data[key]);
        }
    })

    let sqlQuery = `update custom_functional_message_module_settings set ${setArray.join(', ')} where id = ${currentId}`;

    try{
        let SQLresult = await client.query(sqlQuery,values);
        res.json({ msg: 'Success ', data: [] });
    } catch(e) {
        console.error(e.stack)
        res.send({ msg: 'Error ', data: e });
    }

}



export const updateMultipleSetting = async (req, res) => {

    const client = new Client(connectionProps)
    client.connect();

    let updatedCounter = 0;
    let failedToUpdateCounter = 0;

    for(let i = 0; i < req.body.length ; i++) {
        let data = req.body[i];
        let values = [];
        let setArray = [];
        let counter = 0;
        let currentId = req.params.settingId;

        Object.keys(data).forEach( (key, index) => {
            if(key == 'id') {
                currentId = data[key];
            } else {
                counter++;
                setArray.push(`${key} = $${counter}`);
                values.push(data[key]);
            }
        })

        let sqlQuery = `update custom_functional_message_module_settings set ${setArray.join(', ')} where id = ${currentId}`;

        try{
            let SQLresult = await client.query(sqlQuery,values);
            updatedCounter++;
        } catch(e) {
            console.error(e.stack)
            failedToUpdateCounter++;
        }
    }

    res.json({"Updated":updatedCounter, "FailedToUpdate":failedToUpdateCounter});
}





export const deleteSetting = async (req, res) => {


    const client = new Client(connectionProps)
    client.connect()

    let sqlQuery = '';
    let SQLresult = {};
    var tag_code;

    sqlQuery = `SELECT * FROM custom_functional_message_module_settings where id=${req.params.settingId}`;
    console.log(sqlQuery);
    try{
        let SQLresult = await client.query(sqlQuery);
            tag_code = SQLresult.rows[0].tag_code;
    } catch(e) {
        console.error(e.stack)
        res.send({ msg: 'Error ', data: 'Error while query postgres' });
    }


    console.log("DELETE SETTINGS IS CALLED----------------------------");
    sqlQuery = `DELETE FROM custom_functional_message_module_settings where id=${req.params.settingId}`;
    console.log(sqlQuery);
    try{
        let SQLresult = await client.query(sqlQuery);
    } catch(e) {
        console.error(e.stack)
        res.send({ msg: 'Error ', data: 'Error while query postgres' });
    }

    // look for each customer which has a tag coded multiple of tag_code in given settingID and update tag code for all those contacts;

    console.log("update contacts IS CALLED----------------------------");
    sqlQuery = `update custom_functional_message_module_contacts set tag = tag/${tag_code} where tag%${tag_code} = 0;`;
    console.log(sqlQuery);
    try{
        let SQLresult = await client.query(sqlQuery);
        console.log(SQLresult);
        res.json({ msg: 'Success ', contactsUpdated : SQLresult.rowCount, tagDeleted : tag_code });
    } catch(e) {
        console.error(e.stack)
        res.send({ msg: 'Error ', data: 'Error while query postgres' });
    }

    // --------------------------------------------------------------------------------------------------------------------------------
}

function primeFactors(n){
    var factors = [], 
        divisor = 2;

    if(n == 2 )
        factors.push(2);

    while(n>2){
        if(n % divisor == 0){
            factors.push(divisor); 
            n= n/ divisor;
        }
        else{
        divisor++;
        }     
    }
    return factors;
}


function isPrime (num) {
    if (num <= 1) {
      return true
    } else if (num <= 3) {
      return true
    } else if (num%2 === 0 || num%3 === 0) {
      return false
    }
   
    let i = 5
    while (i*i <= num) {
      if (num%i === 0 || num%(i+2) === 0) {
        return false
      }
      i += 6
    }
    return true
  }