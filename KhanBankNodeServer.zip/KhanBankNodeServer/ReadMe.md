ToDo:
------------------------
seeder: to insert 5000000 contacts with random phone1, phone2, phone3 (10,8 digits) and cif_no(12,16 digit) varchars : Done
Complete : 
    POST: Done
    PUT: 
    DELETE: Done

------------------------

Move to the UI Now, 
------------------------

fuck the react froms..  dont yet let use the form..... fuck the world.. 
move with tha native for now, with state management....
---- In the old app we will need to use the Redux else it would not be possible to complete the Designing.. 


what you need to do is to consume th api's an dwhen ever needed create the data and send it ti the athe prvided api's
