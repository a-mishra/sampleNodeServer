import { 
    addNewSetting, 
    getSettings, 
    getSettingWithId,
    getSettingWithTagCode, 
    updateSetting,
    updateMultipleSetting,
    deleteSetting 
} from '../controllers/settingController';

const settingRoutes = (app) => {
    
    app.route('/setting')
        .get((req, res, next) => {
            // middleware
            console.log(`Request from: ${req.originalUrl}`)
            console.log(`Request type: ${req.method}`)
            next();
        }, getSettings)
        
        // POST endpoint
        .post( (req,res,next) => {
            // middleware
            console.log(`Request from: ${req.originalUrl}`);
            console.log(`Request from: ${req.method}`);
            //console.log(req);
            next();
        } , addNewSetting)
        
        // put request
        .put(updateMultipleSetting);


    app.route('/setting/:settingId')
        // get Settings For Id
        .get(getSettingWithId)
        
        // put request
        .put(updateSetting)

        // delete request
        .delete(deleteSetting);

        app.route('/settingfortag/:tagId')
        // get Settings For TagCode
        .get(getSettingWithTagCode);

}

export default settingRoutes;
